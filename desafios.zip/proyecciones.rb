data = open('ventas_base.db').read.split(',')

def proyecciones(closeout)
    venta_1 = []
    venta_2 = []
    ventas1 = 0
    ventas2 = 0

    n = closeout.count
    n.times do |i|
        if i<=5
            venta_1.push closeout[i].to_i
        else 
            venta_2.push closeout[i].to_i
        end
    end
    venta_1.each do |i|
        ventas1 += i
    end 
    sum1 = ventas1 * 1.1 + ventas1
    sum2 = ventas2 * 1.2 + ventas2
    add_year = []
    add_year.push sum1.truncate(2), sum2.truncate(2)
    File.write('resultados.data', add_year)
end

print proyecciones(data)